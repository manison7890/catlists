// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/*
 * Catlists CTL ICO starter implementation.
 * Dependencies: OpenZeppelin Contracts v5.x
 *   @openzeppelin/contracts/token/ERC20/ERC20.sol
 *   @openzeppelin/contracts/token/ERC20/IERC20.sol
 *   @openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol
 *   @openzeppelin/contracts/access/Ownable.sol
 *   @openzeppelin/contracts/utils/ReentrancyGuard.sol
 *
 * IMPORTANT:
 * - Prices are USDT per CTL, represented as 18-decimal fixed-point values.
 * - ETH contributions use configured Chainlink ETH/USD and USDT/USD feeds.
 * - Feed addresses, token allocations, public-sale settings, and TGE must be
 *   verified for the target network before deployment.
 * - This is a development baseline, not an audited production contract.
 */

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface IAggregatorV3 {
    function decimals() external view returns (uint8);
    function latestRoundData()
        external
        view
        returns (
            uint80 roundId,
            int256 answer,
            uint256 startedAt,
            uint256 updatedAt,
            uint80 answeredInRound
        );
}

contract CatlistsToken is ERC20, Ownable {
    uint256 public constant TOTAL_SUPPLY = 3_000_000 ether;

    constructor(address initialOwner)
        ERC20("Catlists Token", "CTL")
        Ownable(initialOwner)
    {
        require(initialOwner != address(0), "zero owner");
        _mint(initialOwner, TOTAL_SUPPLY);
    }
}

contract CatlistsICO is Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint256 public constant WAD = 1e18;
    uint256 public constant ROUND_DURATION = 30 days;
    uint256 public constant TGE_BPS = 2_000; // 20%
    uint256 public constant BPS = 10_000;
    uint256 public constant VESTING_MONTHS = 12;
    uint256 public constant MAX_FEED_AGE = 1 days;

    enum SaleRound { Presale1, Presale2, Presale3, PublicSale, Finished }

    struct Round {
        uint256 priceUsdtWad; // USDT per CTL, 18-decimal fixed point
        uint256 allocation;   // CTL token units (18 decimals)
        uint256 sold;         // CTL token units (18 decimals)
        uint64 startTime;
        uint64 endTime;
        bool configured;
    }

    struct Investor {
        uint256 purchased;
        uint256 claimed;
        uint256 contributedUsdtWad;
    }

    CatlistsToken public immutable token;
    IERC20 public immutable usdt;
    IAggregatorV3 public ethUsdFeed;
    IAggregatorV3 public usdtUsdFeed;

    Round[4] public rounds;
    SaleRound public currentRound;
    uint64 public tgeTime;
    bool public salePaused;

    mapping(address => Investor) public investors;
    mapping(address => mapping(uint8 => uint256)) public purchasedByRound;

    event Purchased(
        address indexed buyer,
        uint8 indexed round,
        address indexed paymentToken,
        uint256 paymentAmount,
        uint256 tokenAmount
    );
    event TokensClaimed(address indexed investor, uint256 amount);
    event RoundConfigured(uint8 indexed round, uint256 priceUsdtWad, uint256 allocation);
    event RoundAdvanced(uint8 indexed oldRound, uint8 indexed newRound);
    event TGEUpdated(uint64 tgeTime);
    event SalePauseUpdated(bool paused);
    event ProceedsWithdrawn(address indexed recipient, address indexed asset, uint256 amount);
    event FeedsUpdated(address ethUsdFeed, address usdtUsdFeed);

    constructor(
        address initialOwner,
        address tokenAddress,
        address usdtAddress,
        address ethUsdFeedAddress,
        address usdtUsdFeedAddress
    ) Ownable(initialOwner) {
        require(initialOwner != address(0), "zero owner");
        require(tokenAddress != address(0) && usdtAddress != address(0), "zero token");
        require(ethUsdFeedAddress != address(0) && usdtUsdFeedAddress != address(0), "zero feed");

        token = CatlistsToken(tokenAddress);
        usdt = IERC20(usdtAddress);
        ethUsdFeed = IAggregatorV3(ethUsdFeedAddress);
        usdtUsdFeed = IAggregatorV3(usdtUsdFeedAddress);
        currentRound = SaleRound.Presale1;
    }

    // Configure all rounds before launch. Prices: 0.0005, 0.0010, 0.0015 USDT/CTL.
    // Public sale price and allocations are intentionally supplied by the owner.
    function configureRound(
        uint8 roundId,
        uint256 priceUsdtWad,
        uint256 allocation,
        uint64 startTime
    ) external onlyOwner {
        require(roundId < 4, "invalid round");
        require(priceUsdtWad > 0 && allocation > 0, "invalid config");
        require(startTime >= block.timestamp, "start in past");
        require(rounds[roundId].sold == 0, "round already sold");
        uint64 endTime = startTime + uint64(ROUND_DURATION);
        rounds[roundId] = Round({
            priceUsdtWad: priceUsdtWad,
            allocation: allocation,
            sold: 0,
            startTime: startTime,
            endTime: endTime,
            configured: true
        });
        emit RoundConfigured(roundId, priceUsdtWad, allocation);
    }

    function setTGE(uint64 tge) external onlyOwner {
        require(tge > block.timestamp, "TGE must be future");
        tgeTime = tge;
        emit TGEUpdated(tge);
    }

    function setPriceFeeds(address ethUsd, address usdtUsd) external onlyOwner {
        require(ethUsd != address(0) && usdtUsd != address(0), "zero feed");
        ethUsdFeed = IAggregatorV3(ethUsd);
        usdtUsdFeed = IAggregatorV3(usdtUsd);
        emit FeedsUpdated(ethUsd, usdtUsd);
    }

    function setSalePaused(bool paused) external onlyOwner {
        salePaused = paused;
        emit SalePauseUpdated(paused);
    }

    // Call after a round has ended or sold out. Rounds are sequential and do not overlap.
    function advanceRound() external {
        uint8 current = uint8(currentRound);
        require(current < 4, "sale finished");
        Round storage r = rounds[current];
        require(r.configured, "round not configured");
        require(
            block.timestamp >= r.endTime || r.sold >= r.allocation,
            "round still active"
        );

        uint8 next = current + 1;
        uint8 old = current;
        if (next >= 4) {
            currentRound = SaleRound.Finished;
        } else {
            require(rounds[next].configured, "next round not configured");
            // Do not start the next round before its configured start time.
            require(block.timestamp >= rounds[next].startTime, "next round not started");
            currentRound = SaleRound(next);
        }
        emit RoundAdvanced(old, uint8(currentRound));
    }

    function buyWithUSDT(uint256 usdtAmount) external nonReentrant {
        require(usdtAmount > 0, "zero payment");
        _requireSaleOpen();
        uint256 usdtUsdWad = _readUsdPrice(usdtUsdFeed);
        // Convert raw USDT units (assumed 6 decimals) to USD WAD using the feed.
        uint256 usdWad = (usdtAmount * usdtUsdWad) / 1e6;
        uint256 tokensOut = (usdWad * WAD) / rounds[uint8(currentRound)].priceUsdtWad;
        _recordPurchase(msg.sender, uint8(currentRound), address(usdt), usdtAmount, tokensOut, usdWad);
        usdt.safeTransferFrom(msg.sender, address(this), usdtAmount);
    }

    function buyWithETH() external payable nonReentrant {
        require(msg.value > 0, "zero payment");
        _requireSaleOpen();
        uint256 ethUsdWad = _readUsdPrice(ethUsdFeed);
        uint256 usdtUsdWad = _readUsdPrice(usdtUsdFeed);
        uint256 usdWad = (msg.value * ethUsdWad) / 1e18;
        // Price is denominated in USDT; convert USD value to USDT value.
        uint256 usdtValueWad = (usdWad * WAD) / usdtUsdWad;
        uint256 tokensOut = (usdtValueWad * WAD) / rounds[uint8(currentRound)].priceUsdtWad;
        _recordPurchase(msg.sender, uint8(currentRound), address(0), msg.value, tokensOut, usdtValueWad);
    }

    function _requireSaleOpen() internal view {
        require(!salePaused, "sale paused");
        uint8 id = uint8(currentRound);
        require(id < 4, "sale finished");
        Round storage r = rounds[id];
        require(r.configured, "round not configured");
        require(block.timestamp >= r.startTime && block.timestamp < r.endTime, "round inactive");
        require(r.sold < r.allocation, "round sold out");
    }

    function _recordPurchase(
        address buyer,
        uint8 roundId,
        address paymentToken,
        uint256 paymentAmount,
        uint256 tokensOut,
        uint256 contributionUsdtWad
    ) internal {
        Round storage r = rounds[roundId];
        require(tokensOut > 0, "too small");
        require(tokensOut <= r.allocation - r.sold, "exceeds round allocation");
        require(token.balanceOf(address(this)) >= tokensOut, "insufficient CTL inventory");

        r.sold += tokensOut;
        investors[buyer].purchased += tokensOut;
        investors[buyer].contributedUsdtWad += contributionUsdtWad;
        purchasedByRound[buyer][roundId] += tokensOut;

        emit Purchased(buyer, roundId, paymentToken, paymentAmount, tokensOut);
    }

    function claimable(address investor) public view returns (uint256) {
        Investor storage account = investors[investor];
        if (account.purchased == 0 || tgeTime == 0 || block.timestamp < tgeTime) return 0;

        uint256 total = account.purchased;
        uint256 unlocked = (total * TGE_BPS) / BPS;
        uint256 elapsedMonths = (block.timestamp - tgeTime) / 30 days;
        if (elapsedMonths > VESTING_MONTHS) elapsedMonths = VESTING_MONTHS;

        // Remaining 80% vests in 12 equal monthly tranches.
        unlocked += ((total * (BPS - TGE_BPS) / BPS) * elapsedMonths) / VESTING_MONTHS;
        if (elapsedMonths == VESTING_MONTHS) unlocked = total;

        if (unlocked <= account.claimed) return 0;
        return unlocked - account.claimed;
    }

    function claim() external nonReentrant {
        uint256 amount = claimable(msg.sender);
        require(amount > 0, "nothing to claim");
        investors[msg.sender].claimed += amount;
        token.transfer(msg.sender, amount);
        emit TokensClaimed(msg.sender, amount);
    }

    function withdrawProceeds(address asset, address recipient, uint256 amount)
        external
        onlyOwner
        nonReentrant
    {
        require(recipient != address(0), "zero recipient");
        if (asset == address(0)) {
            require(amount <= address(this).balance, "insufficient ETH");
            (bool ok, ) = payable(recipient).call{value: amount}("");
            require(ok, "ETH transfer failed");
        } else {
            IERC20(asset).safeTransfer(recipient, amount);
        }
        emit ProceedsWithdrawn(recipient, asset, amount);
    }

    function _readUsdPrice(IAggregatorV3 feed) internal view returns (uint256) {
        (, int256 answer, , uint256 updatedAt, ) = feed.latestRoundData();
        require(answer > 0, "invalid oracle answer");
        require(updatedAt != 0 && updatedAt <= block.timestamp, "invalid oracle time");
        require(block.timestamp - updatedAt <= MAX_FEED_AGE, "stale oracle");
        uint8 feedDecimals = feed.decimals();
        uint256 raw = uint256(answer);
        if (feedDecimals < 18) return raw * (10 ** (18 - feedDecimals));
        if (feedDecimals > 18) return raw / (10 ** (feedDecimals - 18));
        return raw;
    }

    receive() external payable {
        revert("use buyWithETH");
    }
}
