# Catlists (CTL) ICO smart contracts

## Included
- `CatlistsICO.sol`
  - ERC-20 CTL token with fixed supply of 3,000,000 tokens
  - Presale rounds 1, 2, 3 and public sale
  - ETH and USDT contributions
  - Chainlink ETH/USD and USDT/USD feeds
  - Per-round 30-day windows, allocations and configurable prices
  - 20% TGE unlock plus 12 monthly vesting tranches
  - Investor purchase accounting, claim function, owner proceeds withdrawal, pause switch

## Important assumptions / open items
1. The questionnaire gives prices `0.0005`, `0.0010`, `0.0015` but does not state the denomination. This implementation assumes **USDT per CTL**.
2. USDT is assumed to use 6 decimals, as on Ethereum mainnet.
3. The public-sale price and allocation for each round are not provided and must be decided.
4. Total supply is 3,000,000 CTL (18 decimals). The owner must transfer enough CTL to the ICO contract before accepting purchases. The ICO contract does not mint tokens.
5. Configure each round's start timestamp. Each configured round lasts 30 days. `advanceRound()` must be called after a round ends or sells out; the next round cannot accept purchases until it is advanced and its configured start time has arrived.
6. TGE must be configured before investors can claim.
7. ETH/USD and USDT/USD Chainlink feed addresses must be appropriate for the chosen network. Do not deploy with guessed or testnet-inappropriate feed addresses.
8. There are no minimum/maximum investor contributions, as requested.
9. Staking is not included; it was specified as a later feature.

## Dependencies
Use Solidity 0.8.24 and OpenZeppelin Contracts v5.x. Install OpenZeppelin in your Hardhat/Foundry project.

## Deployment outline
1. Deploy `CatlistsToken(initialOwner)`.
2. Deploy `CatlistsICO(initialOwner, tokenAddress, usdtAddress, ethUsdFeedAddress, usdtUsdFeedAddress)`.
3. Transfer the intended sale inventory of CTL from the token owner to the ICO contract.
4. Configure the four rounds using `configureRound(roundId, priceUsdtWad, allocation, startTime)`.
   - Round 0 price: `500000000000000` (0.0005 USDT)
   - Round 1 price: `1000000000000000` (0.0010 USDT)
   - Round 2 price: `1500000000000000` (0.0015 USDT)
   - Round 3: public-sale price to be confirmed
   - Allocation is expressed in 18-decimal token base units (e.g. 100 CTL = `100 * 10**18`).
5. Set TGE using `setTGE(timestamp)`.
6. Verify all parameters, run unit tests and fuzz/invariant tests, and arrange an independent security audit before mainnet.

## Review notes
- This is a starter implementation and has not been audited.
- It is not a substitute for legal/compliance review of a public token sale.
- Before production, add tests for round transitions, oracle failures/staleness, exact allocation boundaries, rounding, vesting boundaries, failed token transfers, and emergency recovery policies.
- The owner is a privileged account able to withdraw proceeds and pause the sale. Use a multisig in production.
